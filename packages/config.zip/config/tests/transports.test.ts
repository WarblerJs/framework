import { describe, expect, test } from "bun:test";
import { httpConfig } from "../../../playground/src/config/transports/http.config";
import { mcpConfig } from "../../../playground/src/config/transports/mcp.config";
import { tcpConfig } from "../../../playground/src/config/transports/tcp.config";
import { udpConfig } from "../../../playground/src/config/transports/udp.config";
import { webrtcConfig } from "../../../playground/src/config/transports/webrtc.config";
import { wsConfig } from "../../../playground/src/config/transports/ws.config";
import {
  validateHttpConfig,
  validateMcpConfig,
  validateTcpConfig,
  validateUdpConfig,
  validateWebrtcConfig,
  validateWebsocketConfig,
} from "../src/validator";

describe("transport validation", () => {
  test("accepts every playground transport configuration", () => {
    expect(() => validateHttpConfig(httpConfig)).not.toThrow();
    expect(() => validateWebsocketConfig(wsConfig)).not.toThrow();
    expect(() => validateTcpConfig(tcpConfig)).not.toThrow();
    expect(() => validateUdpConfig(udpConfig)).not.toThrow();
    expect(() => validateMcpConfig(mcpConfig)).not.toThrow();
    expect(() => validateWebrtcConfig(webrtcConfig)).not.toThrow();
  });

  test("rejects malformed transport roots and unsafe numbers", () => {
    expect(() => validateHttpConfig({})).toThrow("http.request");
    expect(() =>
      validateUdpConfig({
        socket: { packet: { maxSize: Infinity } },
        sessionTracking: {},
        rateLimit: { onExceeded: "silent_drop" },
      }),
    ).toThrow("safe integer");
    expect(() =>
      validateWebsocketConfig({
        connection: {},
        rateLimit: { onExceeded: "wait", closeCode: 4029 },
      }),
    ).toThrow("websocket.rateLimit.onExceeded");
  });
});
