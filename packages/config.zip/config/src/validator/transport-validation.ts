import { ConfigError } from "../errors";
import { parseByteSize, parseHost, parsePort } from "../parser";
import type { TransportName } from "../types";
import { array, booleanValue, integer, oneOf, pathValue, record, stringValue } from "../utils/validation";

const SIZE_KEY = /(?:size|buffer|threshold|length|bytes)$/iu;
const DURATION_KEY = /(?:ms|timeout|interval|window)$/iu;

function validateTree(value: unknown, path: string, key: string): void {
  if (value === null || value === undefined) throw new ConfigError("must be defined", path);
  if (typeof value === "boolean") return;
  if (typeof value === "number") {
    integer(value, path);
    return;
  }
  if (typeof value === "string") {
    stringValue(value, path);
    if (SIZE_KEY.test(key) && /^\d+(?:b|kb|mb|gb)$/u.test(value)) parseByteSize(value);
    return;
  }
  if (Array.isArray(value)) {
    for (let index = 0; index < value.length; index++) validateTree(value[index], `${path}[${index}]`, key);
    return;
  }
  const object = record(value, path);
  const keys = Object.keys(object);
  if (keys.length === 0 && key !== "perRoute") return;
  for (const childKey of keys) validateTree(object[childKey], `${path}.${childKey}`, childKey);
}

function requireSections(value: unknown, name: TransportName, sections: readonly string[]): Readonly<Record<string, unknown>> {
  const root = record(value, name);
  for (const section of sections) {
    if (!(section in root)) throw new ConfigError("is required", `${name}.${section}`);
  }
  for (const key of Object.keys(root)) {
    if (!sections.includes(key)) throw new ConfigError("is not supported", `${name}.${key}`);
  }
  validateTree(root, name, name);
  return root;
}

export function validateHttp(value: unknown): void {
  const root = requireSections(value, "http", ["request", "rateLimit"]);
  const request = record(root.request, "http.request");
  for (const section of ["body", "headers", "query", "cookies", "path", "timeouts"]) {
    if (!(section in request)) throw new ConfigError("is required", `http.request.${section}`);
  }
  const body = record(request.body, "http.request.body");
  oneOf(body.unknownContentType, ["reject", "ignore"] as const, "http.request.body.unknownContentType");
  const rateLimit = record(root.rateLimit, "http.rateLimit");
  oneOf(rateLimit.onExceeded, ["reject"] as const, "http.rateLimit.onExceeded");
  integer(rateLimit.statusCode, "http.rateLimit.statusCode", 400, 599);
}

export function validateWebsocket(value: unknown): void {
  const root = requireSections(value, "websocket", ["connection", "rateLimit"]);
  const rateLimit = record(root.rateLimit, "websocket.rateLimit");
  oneOf(rateLimit.onExceeded, ["reject_handshake", "close_socket", "throttle"] as const, "websocket.rateLimit.onExceeded");
  integer(rateLimit.closeCode, "websocket.rateLimit.closeCode", 1000, 4999);
}

export function validateTcp(value: unknown): void {
  const root = requireSections(value, "tcp", ["socket", "framing", "rateLimit"]);
  const framing = record(root.framing, "tcp.framing");
  oneOf(framing.type, ["length_delimited", "delimiter_based"] as const, "tcp.framing.type");
}

export function validateUdp(value: unknown): void {
  const root = requireSections(value, "udp", ["socket", "sessionTracking", "rateLimit"]);
  const rateLimit = record(root.rateLimit, "udp.rateLimit");
  oneOf(rateLimit.onExceeded, ["silent_drop"] as const, "udp.rateLimit.onExceeded");
}

export function validateMcp(value: unknown): void {
  const root = requireSections(value, "mcp", ["protocol", "transport", "jsonRpc", "capabilities", "rateLimit"]);
  const protocol = record(root.protocol, "mcp.protocol");
  oneOf(protocol.role, ["server", "client"] as const, "mcp.protocol.role");
  const transport = record(root.transport, "mcp.transport");
  oneOf(transport.layer, ["sse", "stdio"] as const, "mcp.transport.layer");
  const rateLimit = record(root.rateLimit, "mcp.rateLimit");
  oneOf(rateLimit.onExceeded, ["error_response"] as const, "mcp.rateLimit.onExceeded");
}

export function validateWebrtc(value: unknown): void {
  const root = requireSections(value, "webrtc", ["signaling", "ice", "dataChannels", "media"]);
  const signaling = record(root.signaling, "webrtc.signaling");
  oneOf(signaling.connectionType, ["websocket"] as const, "webrtc.signaling.connectionType");
  const ice = record(root.ice, "webrtc.ice");
  const range = record(ice.portRange, "webrtc.ice.portRange");
  const minimum = parsePort(range.min);
  const maximum = parsePort(range.max);
  if (minimum > maximum) throw new ConfigError("minimum must not exceed maximum", "webrtc.ice.portRange");
  const servers = array(ice.iceServers, "webrtc.ice.iceServers");
  if (servers.length === 0) throw new ConfigError("must contain at least one server", "webrtc.ice.iceServers");
  for (let index = 0; index < servers.length; index++) {
    const server = record(servers[index], `webrtc.ice.iceServers[${index}]`);
    const urls = array(server.urls, `webrtc.ice.iceServers[${index}].urls`);
    if (urls.length === 0) throw new ConfigError("must not be empty", `webrtc.ice.iceServers[${index}].urls`);
  }
}
