import { ConfigError } from "../errors";

const BYTE_SIZE_PATTERN = /^(0|[1-9]\d*)(b|kb|mb|gb)$/u;
const MULTIPLIERS: Readonly<Record<string, number>> = Object.freeze({
  b: 1,
  kb: 1024,
  mb: 1024 ** 2,
  gb: 1024 ** 3,
});

/** Parses a canonical byte-size string into a safe integer number of bytes. */
export function parseByteSize(value: unknown): number {
  if (typeof value !== "string") throw new ConfigError("byte size must be a string");
  const match = BYTE_SIZE_PATTERN.exec(value);
  if (match === null) throw new ConfigError("byte size must use an integer followed by b, kb, mb, or gb");
  const amountText = match[1];
  const unit = match[2];
  if (amountText === undefined || unit === undefined) throw new ConfigError("invalid byte size");
  const amount = Number(amountText);
  const multiplier = MULTIPLIERS[unit];
  if (multiplier === undefined || !Number.isSafeInteger(amount)) throw new ConfigError("byte size is unsafe");
  const bytes = amount * multiplier;
  if (!Number.isSafeInteger(bytes)) throw new ConfigError("byte size exceeds the safe integer range");
  return bytes;
}
